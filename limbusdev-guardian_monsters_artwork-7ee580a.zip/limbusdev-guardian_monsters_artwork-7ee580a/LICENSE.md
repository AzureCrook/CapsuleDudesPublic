# License

Unless stated otherwise, everything here is licensed under Creative Commons Attribution 4.0 (CC-BY-4.0). See [CC-BY-4.0 License](https://creativecommons.org/licenses/by/4.0/) for more information.

This means you are free to use the artwork in any way you want. The only thing you have to do is, giving proper credit to me in your software's credits screen (in software) like this:

> Includes Guardian Monsters Artwork by Georg Eckert / lucidtanooki

# Exceptions

There are very few exceptions, but they must be named here.

## Guardian Monsters Logo

The Guardian Monsters Logo is copyrighted. All rights reserved. Please do not use it.

## Monsters

You are allowed to use the monsters in any way you want (CC-BY-4.0). I would be happy if you would use the names I gave them, so they are known under the same names everywhere and are recognized. But this is not mandatory anymore.

# Problems

If you have any problems with the license, or if you are not sure, if you're allowed to use them for your project, simply open an issue and ask ;)
