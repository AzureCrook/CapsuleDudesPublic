Egg [> Fordin](./1.md)

# 0.0 Egg

![](../128x128/0_0.png)

## Description

It's color and size are hints about what could hatch.
