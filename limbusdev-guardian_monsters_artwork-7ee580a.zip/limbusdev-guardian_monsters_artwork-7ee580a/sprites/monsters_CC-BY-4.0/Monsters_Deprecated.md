# Deprecated Monsters

The monsters in this directory (see table) are not used by Guardian Monsters anymore and are released in clean CC-BY-4.0 manner. That means you are free to do whatever you want with them, as long as you give proper credit.

The restriction to keep the given names, as with the other guardian monsters, does not apply here.

|Type           |Sprite                     |
|---------------|---------------------------|
|Dinosaur       |![](./000_dinosaur.png)    |
|Turtle         |![](./001_turtle.png)      |
|Turtle man     |![](./002_turtleman.png)   |
|Antenna bug    |![](./003_antenna_bug.png) |

